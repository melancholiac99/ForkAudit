import os,json,time,subprocess,traceback
from pathlib import Path
D=Path(__file__).parent
pid=json.loads((D/'launch.json').read_text())['pid']
def live():
 try:return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[0]!='Z'
 except FileNotFoundError:return False
while live():time.sleep(30)
s=json.loads((D/'status.json').read_text()) if (D/'status.json').exists() else {}
if s.get('stage') not in ('engineering_complete','failed'):
 with (D/'watchdog_wake.log').open('a') as f:subprocess.run(['codex','queue','--thread',os.environ['CODEX_THREAD_ID'],'--resume','--message',f'【CTHA工程验收控制器退出】检查 {D}/status.json 和 driver.log，先查健康子进程再尽力修复。用户仅要工程验收，核验上传credit-grok后关机；不运行四轮学习验证，不放宽门槛。'],stdout=f,stderr=subprocess.STDOUT,timeout=60)
